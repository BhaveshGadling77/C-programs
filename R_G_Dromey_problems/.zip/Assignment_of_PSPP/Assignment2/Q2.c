#include <stdio.h>
int main()
{
int num1,num2;
scanf("%d %d",&num1,&num2);
int sum = num1+num2;
printf("%d",sum);
return 0;
}
