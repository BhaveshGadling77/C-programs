#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	char arr[7];
	scanf("%s", arr);
	printf("output = %s\n", arr);
	return 0;
}	
